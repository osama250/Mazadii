<?php

return [

    'add_new'      => 'Add New',
    'cancel'       => 'Cancel',
    'save'         => 'Save',
    'edit'         => 'Edit',
    'detail'       => 'Details',
    'back'         => 'Back',
    'action'       => 'Action',
    'id'           => 'Id',
    'created_at'   => 'Created At',
    'updated_at'   => 'Updated At',
    'deleted_at'   => 'Deleted At',
    'are_you_sure' => 'Are you sure?',
];
