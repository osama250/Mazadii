<?php

return array (
  'singular' => 'Admin',
  'plural'   => 'المديرين',
  'fields' =>
  array (
    'id'            => 'Id',
    'name'          => 'الاسم',
    'email'         => 'الايميل',
    'password'      => 'كلمة السر',
    'password_confirmation' => 'تاكيد كلمة السر ',
    'roles'         => 'الادوار',
    'status'        => 'الحالة',
    'actions'       => 'الاختيارات' ,
    'remember_token' => 'Remember Token',
    'created_at'    => 'وقت الانشاء',
    'updated_at'    => 'وقت التعديل',
  ),
);
