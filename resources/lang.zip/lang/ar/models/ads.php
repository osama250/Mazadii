<?php

return array (
    'singular' => 'Ads',
    'plural'   => 'الاعلانات',
    'fields'   =>
  array (
    'id'     => 'Id',
    'photo'  => 'الصور',
    'width'  => 'العرض',
    'height' => 'الطول',
    'page'   => 'الصفخة',
    'link'   => 'اللينك',
  ),
);
