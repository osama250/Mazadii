<?php

return array (
    'singular' => 'التسوق',
    'plural'   => 'الاقسام',
    'fields'   =>
    array (
        'id'         => 'Id',
        'language'   => 'اللغة',
        'name'       => 'الاسم',
        'photo'      => 'الصور',
        'status'     => 'الحالة',
        'type'       => 'النوع',
        'actions'    => 'الاختيارات' ,
    ),
);
