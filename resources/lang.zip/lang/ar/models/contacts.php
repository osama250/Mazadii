<?php

return array(
    'singular' => 'التواصل',
    'plural'   => 'لرسايل',
    'fields'   =>
  array(
    'id'         => 'Id',
    'name'       => 'الاسم',
    'email'      => 'الايميل',
    'subject'    => 'الموضوع',
    'message'    => 'الرسايل',
    'code'       => 'الكود',
    'actions'    => 'الاختيارات' ,
    'created_at' => 'وقت الانشاء',
    'updated_at' => 'وقت التعديل',
  ),
);
