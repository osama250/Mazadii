<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'   => 'الأسئلة الشائعة',
    'fields' =>
  array (
    'id'        => 'الرثم',
    'language'  => 'اللغات',
    'name'      => 'السوال',
    'answer'    => 'الاجابات',
    'action'    => 'الاختيارات'
  ),
);
