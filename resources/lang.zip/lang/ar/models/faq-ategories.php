<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'   => 'الأسئلة الشائعة',
    'fields' =>
  array (
    'id'        => 'الرثم',
    'name'      => 'السوال',
    'action'    => 'الاختيارات'
  ),
);
