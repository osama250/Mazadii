<?php

return array (
  'singular' => 'HistoryOrder',
  'plural' => 'HistoryOrders',
  'fields' => 
  array (
    'id' => 'Id',
    'company_id' => 'Company Name',
    'pharmacy_id' => 'Pharmacy Name',
    'status' => 'Status',
    'order_status' => 'Order Status',
  ),
);
