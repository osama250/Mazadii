<?php

return array (
  'singular' => 'Information',
  'plural'   => 'المعلومات',
  'fields' =>
  array (
    'id'         => 'الرقم',
    'language'   => 'اللغة',
    'name'       => 'الاسم',
    'value'      => 'رقم الهاتف',
    'status'     => 'الحالة',
    'actions'    => 'الاختيارات'
  ),
);
