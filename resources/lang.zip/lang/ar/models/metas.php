<?php

return array (
    'singular' => 'SEO',
    'plural'   => 'مُحسنات محركات البحث',
    'fields' =>
  array (
    'id'            => 'الرقم',
    'language'      => 'اللغة',
    'title'         => 'العنوان',
    'description'   => 'الوصف',
    'keywords'      => 'الكلمات الدالة',
    'page'          => 'الصفحات',
    'status'        => 'الحالة',
    'actions'       => 'الاختيارات' ,
    'created_at'    => 'وقت الانشاء',
    'updated_at'    => 'وقت التعديل',
  ),
);
