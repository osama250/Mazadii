<?php

return array (
  'singular' => 'Newsletter',
  'plural'   => 'النشرات الإخبارية',
  'fields' =>
  array (
    'id'         => 'الرقم',
    'email'      => 'الايميل',
    'actions'    => 'الاختيارات' ,
    'created_at' => 'وقت الانشاء',
    'updated_at' => 'وقت التعديل',
  ),
);
