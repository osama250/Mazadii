<?php

return array (
  'singular' => 'Notification',
  'plural'   => 'الاشعارات',
  'fields' =>
  array (
    'id'         => 'الرقم',
    'title'      => 'العنوان',
    'body'       => 'المحتوى',
    'send_to'    => 'مرسل الى',
    'created_at' => 'وقت الانشاء',
    'updated_at' => 'وقت التعديل',
  ),
);
