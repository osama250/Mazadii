<?php

return array (
  'singular' => 'Page',
  'plural'   => 'الصفحات',
  'fields' =>
  array (
    'id' => 'Id',
    'language'    => 'اللغات',
    'active'      => 'الحالة',
    'in_navbar'   => 'In Navbar',
    'in_footer'   => 'In Footer',
    'name'        => 'الاسم',
    'content'     => 'المحتوى',
    'slug'        => 'اللينك',
    'images'      => 'الصور' ,
    'paragraphs'  => 'المحتوى',
    'actions'     => 'الاختيارات',
    'created_at'  => 'وقت الانشاء',
    'updated_at'  => 'وقت التعديل',
  ),
);
