<?php

return array (
    'singular' => 'Partner',
    'plural'   => 'الشركاء',
    'fields' =>
    array (
        'id'     => 'الرقم',
        'photo'  => 'الصور',
        'name'   => 'الاسم',
        'link'   => 'اللينك',
        'status' => 'الحالة',
    ),
);
