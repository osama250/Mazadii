<?php

return array (
  'singular' => 'ProductReview',
  'plural' => 'ProductReviews',
  'fields' => 
  array (
    'id' => 'Id',
    'pharmacy_id' => 'Pharmacy Id',
    'product_id' => 'Product Id',
    'rate' => 'Rate',
  ),
);
