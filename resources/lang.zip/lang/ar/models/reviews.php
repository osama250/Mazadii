<?php

return array(
    'singular' => 'Review',
    'plural'   => 'التعليقات',
    'fields'   =>
    array(
        'id'      => 'الرقم',
        'product' => 'المنتج',
        'user'    => 'المستخدم',
        'comment' => 'تعليق',
        'actions'  => 'الاختيارات',
    ),
);
