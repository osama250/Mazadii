<?php

return array (
    'singular' => 'Roles',
    'plural'   => 'الادوار',
    'fields'   =>
  array (
    'id'        => 'الرقم',
    'name'      => 'الاسم',
    'actions'   => 'الاختيارات'
  ),
);
