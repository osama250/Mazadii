<?php

return array (
    'singular' => 'Rule',
    'plural'   => 'القواعد',
    'fields' =>
  array (
    'id'          => 'الرقم',
    'title'       => 'العنوان',
    'description' => 'الوصف',
    'actions'     =>  'الاختيارات',
    'created_at'  => 'Created At',
    'updated_at'  => 'Updated At',
  ),
);
