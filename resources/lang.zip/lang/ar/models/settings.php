<?php

return array (
    'singular' => 'Setting',
    'plural' => 'الاعدادات',
    'fields' =>
  array (
    'id'    => 'الرقم',
    'key'   => 'Key',
    'value' => 'Value',
  ),
);
