<?php

return array(
    'singular' => 'Slider',
    'plural'   => 'Sliders',
    'fields' =>
  array(
    'id'            => 'الرقم',
    'photo'         => 'الصور',
    'title'         => 'العنوان',
    'description'   => 'الوصف',
    'button_text'   => 'الكتابة',
    'link'          => 'اللينك',
    'status'        => 'الحالة',
    'sort'          => 'النوع',
    'actions'       => 'الاختيارات',
    'created_at'    => 'وقت الانشاء',
    'updated_at'    => 'وقت التعديل',
  ),
);
