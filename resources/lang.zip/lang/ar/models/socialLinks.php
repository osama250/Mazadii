<?php

return array (
    'singular' => 'SocialLink',
    'plural'   => 'روابط اجتماعية',
    'fields'   =>
  array (
    'id'        => 'Id',
    'name'      => 'الاسم',
    'link'      => 'اللينك',
    'status'    => 'الحالة',
    'actions'   => 'الاختيارات'
  ),
);
