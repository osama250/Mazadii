<?php

return array(
  'singular' => 'Syndicate News',
  'plural' => 'Syndicate News',
  'fields' =>
  array(
    'id' => 'Id',
    'title' => 'Title',
    'body' => 'Body',
    'photo' => 'Photo',
    'status' => 'Status',
    'auther' => 'Auther',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
    'syndicate_id' => 'Syndicate ID',
    'personal_id' => 'Personal ID',
    'attach' => 'Attachments',
  ),
);
