<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'   => 'المعاملات',
    'fields' =>
  array (
    'id'        => 'Id',
    'user'      => 'المستخدم',
    'value'     => 'القيمة' ,
    'action'    => 'الاختيارات',
  ),
);
