<?php

return array (
    'profile' => 'Profile',
    'settings' => 'Settings',
    'shop'     => 'Shops' ,

);
