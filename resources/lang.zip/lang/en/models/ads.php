<?php

return array (
  'singular' => 'Ads',
  'plural' => 'Ads',
  'fields' => 
  array (
    'id' => 'Id',
    'photo' => 'Photo',
    'width' => 'Width',
    'height' => 'Height',
    'page' => 'Page',
    'link' => 'Link',
  ),
);
