<?php

return array (
    'singular' => 'Shops',
    'plural' => 'Categories',
    'fields' =>
    array (
        'id'       => 'Id',
        'name'     => 'Name',
        'photo'    => 'Photo',
        'status'   => 'Status',
        'type'     => 'Type',
        'actions'  => 'Actions' ,
    ),
);
