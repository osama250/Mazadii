<?php

return array(
    'singular' => 'Message',
    'plural'   => 'Messages',
    'fields' =>
    array(
        'id'         => 'Id',
        'name'       => 'Name',
        'email'      => 'Email',
        'phone'      => 'Phone',
        'code'       => 'Code',
        'message'    => 'Message',
        'actions'    => 'Actions' ,
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
