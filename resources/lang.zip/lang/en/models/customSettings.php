<?php

return array (
  'singular' => 'Custom Setting',
  'plural' => 'Custom Settings',
  'fields' => 
  array (
    'name' => 'Name',
    'key' => 'Key',
    'value' => 'Value'
  ),
);
