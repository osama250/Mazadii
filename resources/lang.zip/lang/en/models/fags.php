<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'   => 'Fags',
    'fields' =>
  array (
    'id'        => 'Id',
    'language'  => 'language',
    'name'      => 'Question',
    'answer'    => 'answers',
    'action'    => 'Actions'
  ),
);
