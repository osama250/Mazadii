<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'  => 'FaqCategories',
    'fields' =>
  array (
    'id'        => 'Id',
    'name'      => 'Questions',
    'action'    => 'Acations'
  ),
);
