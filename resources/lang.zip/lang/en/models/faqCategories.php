<?php

return array(
    'singular' => 'Faq Category',
    'plural' => 'Faq Categories',
    'fields' =>
    array(
        'id' => 'ID',
        'name' => 'Name',
        'action' => 'Action',
    ),
);
