<?php

return array (
    'singular' => 'Information',
    'plural'   => 'Information',
    'fields'   =>
  array (
    'id'         => 'Id',
    'language'   => 'languages',
    'name'       => 'Name',
    'value'      => 'Value',
    'status'     => 'Status',
    'actions'    => 'Actions'
  ),
);
