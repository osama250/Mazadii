<?php

return array (
    'singular' => 'Contact',
    'plural'   => 'Newsletters',
    'fields'   =>
  array (
    'id'         => 'Id',
    'email'      => 'Email',
    'actions'    =>  'Actions' ,
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
