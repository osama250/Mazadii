<?php

return array (
  'singular' => 'Paragraph',
  'plural' => 'Paragraphs',
  'fields' => 
  array (
    'id' => 'Id',
    'page_id' => 'Page',
    'text' => 'Text',
    'Select Page' => 'Select Page',
  ),
);
