<?php

return array (
  'singular' => 'Services',
  'plural' => 'Services',
  'fields' =>
  array (
    'id' => 'Id',
    'category_id' => 'Category Id',
    'photo' => 'Photo',
    'btn_name' => 'Button Name',
    'btn_link' => 'Button Link',
    'content'  => 'Content',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
