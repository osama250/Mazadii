<?php

return array(
    'singular' => 'SiteOption',
    'plural' => 'SiteOptions',
    'fields' =>
    array(
        'id' => 'Id',
        'product_duration' => 'Product Duration',
        'deposit_percentage' => 'Deposit Percentage',
        'subscription_fees' => 'Subscription Fees',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
