<?php

return array(
    'singular' => 'Transaction',
    'plural' => 'Transactions',
    'fields' =>
    array(
        'id' => 'Id',
        'user' => 'User',
        'value' => 'Value',
        'action' => 'Action',
    ),
);
