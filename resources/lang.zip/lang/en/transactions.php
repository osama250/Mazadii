<?php

return array (
    'singular' => 'HistoryOrder',
    'plural'  => 'Transactions',
    'fields' =>
  array (
    'id'        => 'Id',
    'user'      => 'User',
    'value'     => 'Value' ,
    'action'    => 'Acations'
  ),
);
